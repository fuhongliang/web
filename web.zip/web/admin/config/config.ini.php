<?php
defined('InShopNC') or exit('Access Invalid!');

$config['sys_log'] 			= true;

return $config;
