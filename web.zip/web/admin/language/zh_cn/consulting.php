<?php
defined('InShopNC') or exit('Access Invalid!');
/**
 * index
 */
$lang['consulting_index_manage']		= '咨询管理';
$lang['consulting']						= '咨询';
$lang['consulting_index_sender']		= '咨询人';
$lang['consulting_index_content']		= '咨询内容';
$lang['consulting_index_object']		= '咨询对象';
$lang['consulting_index_store_name']	= '店铺名称';
$lang['consulting_index_time']			= '咨询时间';
$lang['consulting_index_guest']			= '游客';
$lang['consulting_index_goods']			= '商品';
$lang['consulting_index_group']			= '抢购';
$lang['consulting_index_reply']			= '店主回复';
$lang['consulting_index_help1']			= '会员可在商品信息页对商品进行咨询，系统设置处可设置游客是否能够咨询';
$lang['consulting_index_no_reply']		= '暂无回复';
$lang['consulting_index_unfold']		= '... 【展开】';
$lang['consulting_index_retract']		= ' 【收起】';