<?php
defined('InShopNC') or exit('Access Invalid!');
$lang['flea_index_unable']		= '系统未开启闲置市场功能';
$lang['flea_ldle']				= '闲置物品';
$lang['flea_all_ldle']			= '所有闲置物品';
$lang['flea_ldle_name']			= '闲置物品名';
$lang['flea_release_member']	= '发布会员名';
