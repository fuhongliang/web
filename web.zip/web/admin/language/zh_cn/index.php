<?php
defined('InShopNC') or exit('Access Invalid!');

/**
 * 修改密码
 */
$lang['index_modifypw_repeat_error']		= '两次输入的密码不一致，请重新输入';
$lang['index_modifypw_admin_error']			= '管理员信息错误';
$lang['index_modifypw_oldpw_error']			= '原密码错误';
$lang['index_modifypw_success']				= '密码设置成功';
$lang['index_modifypw_fail']				= '密码设置失败';
$lang['index_modifypw_oldpw']				= '原密码';
$lang['index_modifypw_newpw']				= '新密码';
$lang['index_modifypw_newpw2']				= '确认密码';