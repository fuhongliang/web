<?php
defined('InShopNC') or exit('Access Invalid!');

$lang['admin_snsstrace_storename']	= '店舖名稱';
$lang['store_sns_coupon_price']		= '優惠券面額';
$lang['store_sns_start-stop_time']	= '	起止時間';
$lang['store_sns_formerprice']		= '促銷價格';
$lang['store_sns_bundling_price']	= '套餐價格';
$lang['store_sns_free_shipping']	= '免運費';
$lang['store_sns_goodsprice']		= '商品原價';
$lang['store_sns_groupprice']		= '團購價格';
$lang['sns_sharegoods_price']		= '價&nbsp;&nbsp;格';
$lang['sns_sharegoods_freight']		= '運&nbsp;&nbsp;費';
$lang['store_sns_trace_type']		= '動態類型';
$lang['store_sns_normal']			= '新鮮事';
$lang['store_sns_new']				= '新品';
$lang['store_sns_coupon']			= '優惠券';
$lang['store_sns_xianshi']			= '限時折扣';
$lang['store_sns_mansong']			= '滿即送';
$lang['store_sns_bundling']			= '組合銷售';
$lang['store_sns_groupbuy']			= '團購';
$lang['store_sns_recommend']		= '推薦';
$lang['store_sns_hotsell']			= '熱銷';

$lang['store_sns_new_selease']		= '新品發佈';
$lang['store_sns_coupon']			= '優惠券';
$lang['store_sns_xianshi']			= '限時折扣';
$lang['store_sns_mansong']			= '滿即送';
$lang['store_sns_bundling']			= '組合銷售';
$lang['store_sns_gronpbuy']			= '團購';
$lang['store_sns_store_recommend']	= '店舖推薦';
$lang['store_sns_hotsell']			= '熱銷商品';