<?php
defined('InShopNC') or exit('Access Invalid!');
/**
 * index
 */
$lang['login_index_username_null']				= '用戶名不能為空';
$lang['login_index_password_null']				= '密碼不能為空';
$lang['login_index_checkcode_null']				= '驗證碼不能為空';
$lang['login_index_checkcode_wrong']			= '驗證碼輸入錯誤，請重新輸入';
$lang['login_index_not_admin']					= '您不是管理員，不能進入後台';
$lang['login_index_username_password_wrong']	= '帳號密碼錯誤';
$lang['login_index_need_login']					= '您需要登錄後才可以使用本功能';
$lang['login_index_username']					= '用戶名';
$lang['login_index_password']					= '密　碼';
$lang['login_index_checkcode']					= '驗證碼';
$lang['login_index_change_checkcode']			= '看不清,點擊更換驗證碼';
$lang['login_index_back_to_homepage']			= '返回商城首頁';
$lang['login_index_forget_password']			= '忘記了密碼';
$lang['login_index_shopnc']						= '好商城V3';